Good morning,

This robot has fake wheels (they're called "decorative wheels" in the .max file) as part of it's decoration. It just wants to blend in with the other robots, but it has four little legs, so it puts fake wheels over its legs to blend in.

I did read the spec, I know that the robots can't move with wheels, but he doesn't. He just thinks they looks nice.

:)